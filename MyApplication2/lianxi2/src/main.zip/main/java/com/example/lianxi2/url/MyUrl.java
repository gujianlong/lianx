package com.example.lianxi2.url;
/*
 *@auther:谷建龙
 *@Date: 2020/1/6
 *@Time:8:57
 *@Description:
 * */


public interface MyUrl {
    String HomeBean = "http://172.17.8.100/small/";
}
