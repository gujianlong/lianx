package com.example.mycart.url;
/*
 *@auther:谷建龙
 *@Date: 2020/2/5
 *@Time:15:02
 *@Description:
 * */


public interface MyUrl {
    String BEANURL = "http://mobile.bwstudent.com/small/";
}
